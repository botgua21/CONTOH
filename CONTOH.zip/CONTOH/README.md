# wabot-aq
Simple WhatsApp Bot

### FOR TERMUX USER
```bash
> pkg update && pkg upgrade
> pkg install git -y
> pkg install nodejs -y
> pkg install ffmpeg -y
> pkg install imagemagick -y
> git clone https://github.com/Arya274/Arya-DN
> cd Arya-DN
> npm install
```
###### Run
```bash
> node . [<session name>] (session name is optional)
```

---------

### FOR WINDOWS/VPS/RDP USER
```bash
> git clone https://github.com/Arya274/Arya-DN
> cd Arya-DN
> npm install
```
###### Run
```bash
> node index.js
```

# Sosmed
```Thanks @Nurotomo
> Instagram: @arpunchs
> YouTube: Drawl Nag
> WhatsApp: 0882-3543-5804
> Credit: Nurotomo
```
